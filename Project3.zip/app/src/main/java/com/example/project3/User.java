package com.example.project3;

public class User {
    public String fullName, dob, username, email;

    public User(){

    }

    public User(String fullName, String dob, String username, String email){
        this.fullName = fullName;
        this.dob = dob;
        this.username = username;
        this.email = email;
    }
}
